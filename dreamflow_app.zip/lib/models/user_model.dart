import 'dart:convert';
import 'dart:math';

class UserModel {
  final String id;
  final String uniqueId;
  final String name;
  final String email;
  final String profileImage;
  final bool isAdmin;
  final bool isBlocked;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.uniqueId,
    required this.name,
    required this.email,
    required this.profileImage,
    this.isAdmin = false,
    this.isBlocked = false,
    required this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] ?? '',
      uniqueId: map['uniqueId'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      profileImage: map['profileImage'] ?? '',
      isAdmin: map['isAdmin'] ?? false,
      isBlocked: map['isBlocked'] ?? false,
      createdAt: DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'uniqueId': uniqueId,
      'name': name,
      'email': email,
      'profileImage': profileImage,
      'isAdmin': isAdmin,
      'isBlocked': isBlocked,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  String toJson() => json.encode(toMap());

  factory UserModel.fromJson(String source) => UserModel.fromMap(json.decode(source));

  UserModel copyWith({
    String? id,
    String? uniqueId,
    String? name,
    String? email,
    String? profileImage,
    bool? isAdmin,
    bool? isBlocked,
    DateTime? createdAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      uniqueId: uniqueId ?? this.uniqueId,
      name: name ?? this.name,
      email: email ?? this.email,
      profileImage: profileImage ?? this.profileImage,
      isAdmin: isAdmin ?? this.isAdmin,
      isBlocked: isBlocked ?? this.isBlocked,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  static String generateUniqueId() {
    final random = Random();
    return '#${random.nextInt(99999).toString().padLeft(5, '0')}';
  }
}