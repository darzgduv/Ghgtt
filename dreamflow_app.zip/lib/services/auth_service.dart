import 'dart:convert';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:staeo/models/user_model.dart';

class AuthService {
  static const String _currentUserKey = 'current_user';
  static const String _usersKey = 'users';
  static const String _adminEmail = 'hmwdyalasbany34@gmail.com';
  static const String _adminPassword = 'gtasan';

  static AuthService? _instance;
  static AuthService get instance => _instance ??= AuthService._();
  AuthService._();

  UserModel? _currentUser;
  List<UserModel> _users = [];

  UserModel? get currentUser => _currentUser;
  List<UserModel> get users => List.unmodifiable(_users);
  List<UserModel> get mutableUsers => _users;

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    
    // Load current user
    final currentUserJson = prefs.getString(_currentUserKey);
    if (currentUserJson != null) {
      _currentUser = UserModel.fromJson(currentUserJson);
    }
    
    // Load all users
    final usersJson = prefs.getString(_usersKey);
    if (usersJson != null) {
      final List<dynamic> usersList = json.decode(usersJson);
      _users = usersList.map((user) => UserModel.fromMap(user)).toList();
    } else {
      await _initializeDefaultUsers();
    }
  }

  Future<void> _initializeDefaultUsers() async {
    // Create admin user
    final admin = UserModel(
      id: 'admin_1',
      uniqueId: '#00001',
      name: 'محمد مال الله الصميدعي',
      email: _adminEmail,
      profileImage: 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
      isAdmin: true,
      createdAt: DateTime.now(),
    );
    
    _users = [admin];
    await _saveUsers();
  }

  Future<bool> login(String email, String password) async {
    final user = _users.firstWhere(
      (u) => u.email.toLowerCase() == email.toLowerCase(),
      orElse: () => throw Exception('المستخدم غير موجود'),
    );

    if (user.isBlocked && !user.isAdmin) {
      throw Exception('تم حظر هذا الحساب');
    }

    // Check admin credentials
    if (user.isAdmin && (email != _adminEmail || password != _adminPassword)) {
      throw Exception('بيانات المشرف غير صحيحة');
    }

    // For non-admin users, accept any password (simplified for demo)
    _currentUser = user;
    await _saveCurrentUser();
    return true;
  }

  Future<UserModel> register(String name, String email, String password) async {
    // Check if user already exists
    final existingUser = _users.where((u) => u.email.toLowerCase() == email.toLowerCase());
    if (existingUser.isNotEmpty) {
      throw Exception('البريد الإلكتروني مستخدم بالفعل');
    }

    final newUser = UserModel(
      id: 'user_${_users.length + 1}',
      uniqueId: UserModel.generateUniqueId(),
      name: name,
      email: email,
      profileImage: 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
      createdAt: DateTime.now(),
    );

    _users.add(newUser);
    await _saveUsers();

    _currentUser = newUser;
    await _saveCurrentUser();

    return newUser;
  }

  Future<void> logout() async {
    _currentUser = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_currentUserKey);
  }

  Future<void> updateProfile(String name, String profileImage) async {
    if (_currentUser == null) return;

    final updatedUser = _currentUser!.copyWith(
      name: name,
      profileImage: profileImage,
    );

    _currentUser = updatedUser;
    
    // Update in users list
    final index = _users.indexWhere((u) => u.id == updatedUser.id);
    if (index != -1) {
      _users[index] = updatedUser;
      await _saveUsers();
    }
    
    await _saveCurrentUser();
  }

  Future<void> deleteAccount() async {
    if (_currentUser == null || _currentUser!.isAdmin) return;

    _users.removeWhere((u) => u.id == _currentUser!.id);
    await _saveUsers();
    await logout();
  }

  Future<void> blockUser(String userId, bool block) async {
    if (_currentUser?.isAdmin != true) return;

    final index = _users.indexWhere((u) => u.id == userId);
    if (index != -1 && !_users[index].isAdmin) {
      _users[index] = _users[index].copyWith(isBlocked: block);
      await _saveUsers();
    }
  }

  UserModel? findUserByUniqueId(String uniqueId) {
    try {
      return _users.firstWhere((u) => u.uniqueId == uniqueId);
    } catch (e) {
      return null;
    }
  }

  Future<void> _saveCurrentUser() async {
    if (_currentUser == null) return;
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_currentUserKey, _currentUser!.toJson());
  }

  Future<void> _saveUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final usersMap = _users.map((user) => user.toMap()).toList();
    await prefs.setString(_usersKey, json.encode(usersMap));
  }

  // Public method for sample data
  Future<void> saveUsers() async {
    await _saveUsers();
  }
}