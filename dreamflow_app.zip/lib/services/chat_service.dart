import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:staeo/models/message_model.dart';
import 'package:staeo/models/user_model.dart';
import 'package:staeo/services/auth_service.dart';
import 'package:staeo/services/friend_service.dart';

class ChatService {
  static const String _messagesKey = 'messages';

  static ChatService? _instance;
  static ChatService get instance => _instance ??= ChatService._();
  ChatService._();

  List<MessageModel> _messages = [];

  List<MessageModel> get mutableMessages => _messages;

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final messagesJson = prefs.getString(_messagesKey);
    
    if (messagesJson != null) {
      final List<dynamic> messagesList = json.decode(messagesJson);
      _messages = messagesList.map((message) => MessageModel.fromMap(message)).toList();
    }
  }

  Future<bool> sendMessage(String receiverId, String content, {MessageType type = MessageType.text}) async {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return false;

    // Check if they are friends (admin can message anyone)
    if (!currentUser.isAdmin && !FriendService.instance.areFriends(currentUser.id, receiverId)) {
      throw Exception('يجب أن تكون صديقاً لهذا المستخدم لإرسال الرسائل');
    }

    final message = MessageModel(
      id: 'msg_${_messages.length + 1}',
      senderId: currentUser.id,
      receiverId: receiverId,
      content: content,
      type: type,
      timestamp: DateTime.now(),
    );

    _messages.add(message);
    await _saveMessages();
    return true;
  }

  List<MessageModel> getConversation(String userId1, String userId2) {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return [];

    // Admin can see all messages
    if (currentUser.isAdmin) {
      return _messages.where((m) => 
        (m.senderId == userId1 && m.receiverId == userId2) ||
        (m.senderId == userId2 && m.receiverId == userId1)
      ).toList()..sort((a, b) => a.timestamp.compareTo(b.timestamp));
    }

    // Regular users can only see their own conversations
    if (currentUser.id != userId1 && currentUser.id != userId2) {
      return [];
    }

    return _messages.where((m) => 
      (m.senderId == userId1 && m.receiverId == userId2) ||
      (m.senderId == userId2 && m.receiverId == userId1)
    ).toList()..sort((a, b) => a.timestamp.compareTo(b.timestamp));
  }

  List<UserModel> getRecentChats() {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return [];

    final recentMessages = _messages
      .where((m) => m.senderId == currentUser.id || m.receiverId == currentUser.id)
      .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

    final seenUserIds = <String>{};
    final recentUsers = <UserModel>[];
    final allUsers = AuthService.instance.users;

    for (final message in recentMessages) {
      final otherUserId = message.senderId == currentUser.id 
        ? message.receiverId 
        : message.senderId;

      if (!seenUserIds.contains(otherUserId)) {
        seenUserIds.add(otherUserId);
        final user = allUsers.where((u) => u.id == otherUserId);
        if (user.isNotEmpty) {
          recentUsers.add(user.first);
        }
      }
    }

    return recentUsers;
  }

  MessageModel? getLastMessage(String userId1, String userId2) {
    final conversation = getConversation(userId1, userId2);
    return conversation.isEmpty ? null : conversation.last;
  }

  int getUnreadCount(String userId) {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return 0;

    return _messages
      .where((m) => 
        m.receiverId == currentUser.id && 
        m.senderId == userId && 
        !m.isRead
      )
      .length;
  }

  Future<void> markMessagesAsRead(String senderId) async {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return;

    for (int i = 0; i < _messages.length; i++) {
      if (_messages[i].receiverId == currentUser.id && 
          _messages[i].senderId == senderId && 
          !_messages[i].isRead) {
        _messages[i] = _messages[i].copyWith(isRead: true);
      }
    }

    await _saveMessages();
  }

  // Admin feature to read all messages
  List<MessageModel> getAllMessages() {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser?.isAdmin != true) return [];

    return _messages..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  Future<void> _saveMessages() async {
    final prefs = await SharedPreferences.getInstance();
    final messagesMap = _messages.map((message) => message.toMap()).toList();
    await prefs.setString(_messagesKey, json.encode(messagesMap));
  }

  // Public method for sample data
  Future<void> saveMessages() async {
    await _saveMessages();
  }
}