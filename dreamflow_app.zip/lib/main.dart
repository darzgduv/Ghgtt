import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:staeo/theme.dart';
import 'package:staeo/screens/splash_screen.dart';

void main() {
  runApp(const StaeoApp());
}

class StaeoApp extends StatelessWidget {
  const StaeoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'STAEO - تطبيق التواصل الاجتماعي',
      debugShowCheckedModeBanner: false,
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: ThemeMode.system,
      locale: const Locale('ar', 'SA'),
      supportedLocales: const [
        Locale('ar', 'SA'),
        Locale('en', 'US'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const SplashScreen(),
    );
  }
}
