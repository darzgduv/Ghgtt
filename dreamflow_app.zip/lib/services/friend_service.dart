import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:staeo/models/friend_model.dart';
import 'package:staeo/models/user_model.dart';
import 'package:staeo/services/auth_service.dart';

class FriendService {
  static const String _friendsKey = 'friends';

  static FriendService? _instance;
  static FriendService get instance => _instance ??= FriendService._();
  FriendService._();

  List<FriendModel> _friends = [];

  List<FriendModel> get mutableFriends => _friends;

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final friendsJson = prefs.getString(_friendsKey);
    
    if (friendsJson != null) {
      final List<dynamic> friendsList = json.decode(friendsJson);
      _friends = friendsList.map((friend) => FriendModel.fromMap(friend)).toList();
    }
  }

  Future<bool> sendFriendRequest(String targetUniqueId) async {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return false;

    final targetUser = AuthService.instance.findUserByUniqueId(targetUniqueId);
    if (targetUser == null) {
      throw Exception('المستخدم غير موجود');
    }

    if (targetUser.id == currentUser.id) {
      throw Exception('لا يمكنك إضافة نفسك كصديق');
    }

    // Check if friendship already exists
    final existingFriendship = _friends.where((f) => 
      (f.userId == currentUser.id && f.friendId == targetUser.id) ||
      (f.userId == targetUser.id && f.friendId == currentUser.id)
    );

    if (existingFriendship.isNotEmpty) {
      throw Exception('طلب الصداقة موجود بالفعل');
    }

    final friendRequest = FriendModel(
      id: 'friend_${_friends.length + 1}',
      userId: currentUser.id,
      friendId: targetUser.id,
      status: FriendshipStatus.pending,
      createdAt: DateTime.now(),
    );

    _friends.add(friendRequest);
    await _saveFriends();
    return true;
  }

  Future<void> acceptFriendRequest(String friendshipId) async {
    final index = _friends.indexWhere((f) => f.id == friendshipId);
    if (index == -1) return;

    _friends[index] = _friends[index].copyWith(
      status: FriendshipStatus.accepted,
      acceptedAt: DateTime.now(),
    );
    
    await _saveFriends();
  }

  Future<void> rejectFriendRequest(String friendshipId) async {
    _friends.removeWhere((f) => f.id == friendshipId);
    await _saveFriends();
  }

  Future<void> blockFriend(String friendshipId) async {
    final index = _friends.indexWhere((f) => f.id == friendshipId);
    if (index == -1) return;

    _friends[index] = _friends[index].copyWith(
      status: FriendshipStatus.blocked,
    );
    
    await _saveFriends();
  }

  List<UserModel> getAcceptedFriends() {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return [];

    final acceptedFriendships = _friends.where((f) => 
      f.status == FriendshipStatus.accepted &&
      (f.userId == currentUser.id || f.friendId == currentUser.id)
    ).toList();

    final friends = <UserModel>[];
    final allUsers = AuthService.instance.users;

    for (final friendship in acceptedFriendships) {
      final friendId = friendship.userId == currentUser.id 
        ? friendship.friendId 
        : friendship.userId;
      
      final friend = allUsers.where((u) => u.id == friendId);
      if (friend.isNotEmpty) {
        friends.add(friend.first);
      }
    }

    return friends;
  }

  List<FriendModel> getPendingRequests() {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return [];

    return _friends.where((f) => 
      f.status == FriendshipStatus.pending &&
      f.friendId == currentUser.id
    ).toList();
  }

  List<FriendModel> getSentRequests() {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return [];

    return _friends.where((f) => 
      f.status == FriendshipStatus.pending &&
      f.userId == currentUser.id
    ).toList();
  }

  bool areFriends(String userId1, String userId2) {
    return _friends.any((f) => 
      f.status == FriendshipStatus.accepted &&
      ((f.userId == userId1 && f.friendId == userId2) ||
       (f.userId == userId2 && f.friendId == userId1))
    );
  }

  Future<void> _saveFriends() async {
    final prefs = await SharedPreferences.getInstance();
    final friendsMap = _friends.map((friend) => friend.toMap()).toList();
    await prefs.setString(_friendsKey, json.encode(friendsMap));
  }

  // Public method for sample data
  Future<void> saveFriends() async {
    await _saveFriends();
  }
}