import 'package:flutter/material.dart';
import 'package:staeo/models/user_model.dart';
import 'package:staeo/services/friend_service.dart';

class CallsScreen extends StatefulWidget {
  const CallsScreen({super.key});

  @override
  State<CallsScreen> createState() => _CallsScreenState();
}

class _CallsScreenState extends State<CallsScreen> with TickerProviderStateMixin {
  List<UserModel> _friends = [];
  late TabController _tabController;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // Mock call history for demo
  final List<Map<String, dynamic>> _callHistory = [
    {
      'name': 'أحمد محمد',
      'uniqueId': '#12345',
      'avatar': 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
      'type': 'video',
      'status': 'outgoing',
      'duration': '05:32',
      'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
    },
    {
      'name': 'فاطمة علي',
      'uniqueId': '#67890',
      'avatar': 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
      'type': 'audio',
      'status': 'incoming',
      'duration': '12:08',
      'timestamp': DateTime.now().subtract(const Duration(days: 1)),
    },
    {
      'name': 'محمد خالد',
      'uniqueId': '#11111',
      'avatar': 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
      'type': 'video',
      'status': 'missed',
      'duration': '00:00',
      'timestamp': DateTime.now().subtract(const Duration(days: 2)),
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _loadFriends();
    _animationController.forward();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _loadFriends() {
    setState(() {
      _friends = FriendService.instance.getAcceptedFriends();
    });
  }

  void _initiateCall(UserModel friend, bool isVideo) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          isVideo ? 'مكالمة فيديو' : 'مكالمة صوتية',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(friend.profileImage),
            ),
            const SizedBox(height: 16),
            Text(
              'الاتصال بـ ${friend.name}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(
              'هذه ميزة تجريبية وستكون متاحة قريباً',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'إلغاء',
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('تم بدء ${isVideo ? "مكالمة الفيديو" : "المكالمة الصوتية"} مع ${friend.name}'),
                  backgroundColor: Theme.of(context).colorScheme.primary,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
            ),
            child: const Text('اتصال'),
          ),
        ],
      ),
    );
  }

  String _formatCallTime(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${difference.inDays} يوم';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} ساعة';
    } else {
      return '${difference.inMinutes} دقيقة';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'المكالمات',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Theme.of(context).colorScheme.surface,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Theme.of(context).colorScheme.primary,
          unselectedLabelColor: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
          indicatorColor: Theme.of(context).colorScheme.primary,
          indicatorWeight: 3,
          tabs: const [
            Tab(text: 'الأصدقاء'),
            Tab(text: 'السجل'),
          ],
        ),
      ),
      
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: TabBarView(
          controller: _tabController,
          children: [
            _buildFriendsList(),
            _buildCallHistory(),
          ],
        ),
      ),
    );
  }

  Widget _buildFriendsList() {
    if (_friends.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(60),
              ),
              child: Icon(
                Icons.people_outline,
                size: 60,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'لا يوجد أصدقاء',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'أضف أصدقاء لبدء المكالمات',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: _friends.length,
      itemBuilder: (context, index) {
        final friend = _friends[index];
        return _buildFriendCallCard(friend);
      },
    );
  }

  Widget _buildFriendCallCard(UserModel friend) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          radius: 28,
          backgroundImage: NetworkImage(friend.profileImage),
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        ),
        title: Text(
          friend.name,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          friend.uniqueId,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
          ),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              onPressed: () => _initiateCall(friend, false),
              icon: Icon(
                Icons.call,
                color: Theme.of(context).colorScheme.primary,
              ),
              style: IconButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: () => _initiateCall(friend, true),
              icon: Icon(
                Icons.videocam,
                color: Theme.of(context).colorScheme.tertiary,
              ),
              style: IconButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.tertiaryContainer.withValues(alpha: 0.3),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCallHistory() {
    if (_callHistory.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(60),
              ),
              child: Icon(
                Icons.call_outlined,
                size: 60,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'لا يوجد سجل مكالمات',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'ابدأ مكالمتك الأولى مع الأصدقاء',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: _callHistory.length,
      itemBuilder: (context, index) {
        final call = _callHistory[index];
        return _buildCallHistoryCard(call);
      },
    );
  }

  Widget _buildCallHistoryCard(Map<String, dynamic> call) {
    final isVideo = call['type'] == 'video';
    final status = call['status'] as String;
    
    Color statusColor;
    IconData statusIcon;
    
    switch (status) {
      case 'outgoing':
        statusColor = Theme.of(context).colorScheme.primary;
        statusIcon = Icons.call_made;
        break;
      case 'incoming':
        statusColor = Theme.of(context).colorScheme.tertiary;
        statusIcon = Icons.call_received;
        break;
      case 'missed':
        statusColor = Theme.of(context).colorScheme.error;
        statusIcon = Icons.call_received;
        break;
      default:
        statusColor = Theme.of(context).colorScheme.onSurface;
        statusIcon = Icons.call;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          radius: 28,
          backgroundImage: NetworkImage(call['avatar']),
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        ),
        title: Text(
          call['name'],
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Row(
          children: [
            Icon(
              statusIcon,
              size: 16,
              color: statusColor,
            ),
            const SizedBox(width: 4),
            Text(
              '${_formatCallTime(call['timestamp'])} • ${call['duration']}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isVideo ? Icons.videocam : Icons.call,
              color: statusColor,
              size: 20,
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: () {
                // Simulate calling back
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('إعادة الاتصال بـ ${call['name']}'),
                    backgroundColor: Theme.of(context).colorScheme.primary,
                  ),
                );
              },
              icon: Icon(
                isVideo ? Icons.videocam : Icons.call,
                color: Theme.of(context).colorScheme.primary,
              ),
              style: IconButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
              ),
            ),
          ],
        ),
      ),
    );
  }
}