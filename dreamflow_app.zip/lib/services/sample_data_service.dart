import 'package:staeo/models/user_model.dart';
import 'package:staeo/models/friend_model.dart';
import 'package:staeo/models/message_model.dart';
import 'package:staeo/services/auth_service.dart';
import 'package:staeo/services/friend_service.dart';
import 'package:staeo/services/chat_service.dart';

class SampleDataService {
  static const List<Map<String, dynamic>> _sampleUsers = [
    {
      'name': 'أحمد محمد العلي',
      'email': 'ahmed@example.com',
      'profileImage': 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
    },
    {
      'name': 'فاطمة سالم النوري',
      'email': 'fatima@example.com',
      'profileImage': 'https://pixabay.com/get/g7ab04d5dc72dbfdf7c596586ed6fb1768e170399c2d6237934bd385dc7c458c66d33563238a9d981e28db507356582430a8aa65cd11c3199869baa64395e639c_1280.png',
    },
    {
      'name': 'خالد يوسف السلمان',
      'email': 'khalid@example.com',
      'profileImage': 'https://pixabay.com/get/g124a0f5d9d9ffe0ff9d35490ffc9715ce01287d8bb5bb1939fc23e0298c460302cc1be82f4e2162ecfa7a7615da0b4743b2c3ff1e301f95f675c354998eefe77_1280.jpg',
    },
    {
      'name': 'نورا عبدالله الزهراني',
      'email': 'nora@example.com',
      'profileImage': 'https://pixabay.com/get/g2d4936e3340c6c53b5fe1157e723490194e868c0bbbd5b102a37801055a2fa71c2b49be6a175d297dc5b7588f96d8e45960ef0cf51bbc4f6dfb0d3826f597f7e_1280.jpg',
    },
    {
      'name': 'محمد سعد الدوسري',
      'email': 'mohammed@example.com',
      'profileImage': 'https://pixabay.com/get/g7ab04d5dc72dbfdf7c596586ed6fb1768e170399c2d6237934bd385dc7c458c66d33563238a9d981e28db507356582430a8aa65cd11c3199869baa64395e639c_1280.png',
    },
  ];

  static const List<String> _sampleMessages = [
    'السلام عليكم ورحمة الله وبركاته',
    'كيف حالك؟ أتمنى أن تكون بخير',
    'شكراً لك على المساعدة',
    'هل يمكننا الاجتماع غداً؟',
    'لدي فكرة رائعة أريد مشاركتها معك',
    'ما رأيك في هذا الاقتراح؟',
    'أعتقد أن هذا المشروع سيكون ناجحاً',
    'تهانينا على الإنجاز الرائع!',
    'أتطلع للقائك قريباً',
    'بالتوفيق في عملك الجديد',
    'هذا التطبيق رائع حقاً!',
    'أحب التصميم الجديد',
    'الوضع الليلي يبدو مذهلاً',
    'شكراً لإضافتي كصديق',
    'أهلاً وسهلاً بك في STAEO',
  ];

  static Future<void> createSampleData() async {
    final authService = AuthService.instance;
    final currentUsers = authService.users;
    
    // Only create sample data if we have less than 3 users (admin + samples)
    if (currentUsers.length >= 6) return;

    // Create sample users
    final List<UserModel> sampleUsers = [];
    
    for (int i = 0; i < _sampleUsers.length; i++) {
      final userData = _sampleUsers[i];
      
      // Check if user already exists
      final existingUser = currentUsers.where(
        (u) => u.email == userData['email']
      );
      
      if (existingUser.isEmpty) {
        final user = UserModel(
          id: 'sample_user_${i + 1}',
          uniqueId: UserModel.generateUniqueId(),
          name: userData['name'],
          email: userData['email'],
          profileImage: userData['profileImage'],
          createdAt: DateTime.now().subtract(Duration(days: i + 1)),
        );
        
        sampleUsers.add(user);
        
        // Add to auth service
        authService.mutableUsers.add(user);
      }
    }

    // Save updated users
    await authService.saveUsers();

    // Create sample friendships (only if we have sample users)
    if (sampleUsers.isNotEmpty) {
      final friendService = FriendService.instance;
      final currentUser = authService.currentUser;
      
      if (currentUser != null && !currentUser.isAdmin) {
        // Make current user friends with first two sample users
        for (int i = 0; i < 2 && i < sampleUsers.length; i++) {
          final friendship = FriendModel(
            id: 'sample_friendship_${i + 1}',
            userId: currentUser.id,
            friendId: sampleUsers[i].id,
            status: FriendshipStatus.accepted,
            createdAt: DateTime.now().subtract(Duration(hours: i + 1)),
            acceptedAt: DateTime.now().subtract(Duration(minutes: i * 30)),
          );
          
          friendService.mutableFriends.add(friendship);
        }
        
        // Create pending friendship request from third user
        if (sampleUsers.length > 2) {
          final pendingRequest = FriendModel(
            id: 'sample_pending_1',
            userId: sampleUsers[2].id,
            friendId: currentUser.id,
            status: FriendshipStatus.pending,
            createdAt: DateTime.now().subtract(const Duration(hours: 2)),
          );
          
          friendService.mutableFriends.add(pendingRequest);
        }
        
        await friendService.saveFriends();
      }

      // Create sample messages
      if (currentUser != null && !currentUser.isAdmin && sampleUsers.isNotEmpty) {
        final chatService = ChatService.instance;
        
        // Create conversation with first sample user
        if (sampleUsers.isNotEmpty) {
          final friend = sampleUsers[0];
          
          for (int i = 0; i < 5; i++) {
            final isFromCurrentUser = i % 2 == 0;
            final message = MessageModel(
              id: 'sample_message_${i + 1}',
              senderId: isFromCurrentUser ? currentUser.id : friend.id,
              receiverId: isFromCurrentUser ? friend.id : currentUser.id,
              content: _sampleMessages[i % _sampleMessages.length],
              timestamp: DateTime.now().subtract(Duration(minutes: (5 - i) * 10)),
              isRead: true,
            );
            
            chatService.mutableMessages.add(message);
          }
        }

        // Create conversation with second sample user
        if (sampleUsers.length > 1) {
          final friend = sampleUsers[1];
          
          for (int i = 0; i < 3; i++) {
            final isFromCurrentUser = i % 2 == 1;
            final message = MessageModel(
              id: 'sample_message_2_${i + 1}',
              senderId: isFromCurrentUser ? currentUser.id : friend.id,
              receiverId: isFromCurrentUser ? friend.id : currentUser.id,
              content: _sampleMessages[(i + 5) % _sampleMessages.length],
              timestamp: DateTime.now().subtract(Duration(hours: i + 1)),
              isRead: i < 2,
            );
            
            chatService.mutableMessages.add(message);
          }
        }
        
        await chatService.saveMessages();
      }
    }
  }
}